package com.example.birthdeathregistration

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.birthdeathregistration.Admin.AdminRequests
import com.example.birthdeathregistration.User.UserHistory.historyAdapter
import com.example.birthdeathregistration.databinding.ActivityWorkerdashboradBinding
import com.example.birthdeathregistration.databinding.CardhistoryBinding
import com.example.birthdeathregistration.databinding.CardprofileBinding
import com.example.birthdeathregistration.databinding.CardprofileworkerBinding
import com.example.birthdeathregistration.databinding.CardverficationworkerBinding
import com.example.birthdeathregistration.databinding.CardworkerassginedBinding
import com.example.birthdeathregistration.model.RetrofitClient
import com.example.birthdeathregistration.model.logout
import com.example.skinsmart.model.requestda
import com.example.skinsmart.model.requestresponse
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Workerdashborad : AppCompatActivity() {
    private val b by lazy {
        ActivityWorkerdashboradBinding.inflate(layoutInflater)
    }
    private val bind by lazy {
        CardprofileworkerBinding.inflate(layoutInflater)
    }
    var id=0
    var name=""
    var num=""
    var email=""
    var address=""
    var city=""
    var pass=""
    var type=""
    var status=""
    private lateinit var p: AlertDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(b.root)

        getSharedPreferences("user", MODE_PRIVATE).apply {
            num=getString("num","").toString()
            pass=getString("pass","").toString()
            email=getString("email","").toString()
            name=getString("name","").toString()
            address=getString("address","").toString()
            city=getString("city","").toString()
            type=getString("type","").toString()
            status=getString("status","").toString()
            id=getInt("id",0)
        }

        val k=arrayOf("choose your choice","Available","Not Available")

        b.tvname.text="WELCOME $name"
        ArrayAdapter(this@Workerdashborad,
            android.R.layout.simple_list_item_checked, k).apply {
            bind.spinnerstatus.adapter=this
        }
        k.forEachIndexed { index, s ->
            if(s==status){
                bind.spinnerstatus.setSelection(index,true)
            }
        }

         readassigning(email)
        //menu bar
        b.btnmenu.setOnClickListener {
            val popupMenu: PopupMenu = PopupMenu(this,b.btnmenu)
            popupMenu.menuInflater.inflate(R.menu.menu,popupMenu.menu)
            popupMenu.setOnMenuItemClickListener(PopupMenu.OnMenuItemClickListener { item ->
                when(item.itemId) {
                    R.id.action_profile ->{
                        popupMenu.dismiss()

                        BottomSheetDialog(this).apply {
                            (bind.root.parent as? ViewGroup)?.removeView(bind.root)
                            setContentView(bind.root)

                            bind.btnsubmit.setOnClickListener {
                                BottomSheetDialog(this@Workerdashborad).apply {
                                    (bind.root.parent as? ViewGroup)?.removeView(bind.root)
                                    setContentView(bind.root)
                                    bind.btnsubmit.setOnClickListener {
                                        val name1=bind.etname.text.toString().trim()
                                        val num1=bind.etnum.text.toString().trim()
                                        val status1=bind.spinnerstatus.selectedItem.toString()
                                        val address1=bind.etaddress.text.toString().trim()
                                        val city1=bind.etcity.text.toString().trim()
                                        val password1=bind.etpassword.text.toString().trim()


                                        if(name1.isEmpty()){
                                            bind.etname.error="Enter Your Name"
                                        }else if(num1.isEmpty()){
                                            bind.etnum.error="Enter Your Number"
                                        }else if(address1.isEmpty()){
                                            bind.etaddress.error="Enter Your Address"
                                        }else if(city1.isEmpty()){
                                            bind.etcity.error="Enter Your city"
                                        }else if(password1.isEmpty()){
                                            bind.etpassword.error="Enter Your Password"
                                        }else if(num1.count()!=10){
                                            bind.etnum.error="Enter Your Number properly"
                                        }else{
                                            CoroutineScope(Dispatchers.IO).launch {
                                                RetrofitClient.instance.updateprofile(id,name1,num1,address1,city1,password1,status1,"updateuser")
                                                    .enqueue(object: Callback<DefaultResponse> {
                                                        override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                                            Toast.makeText(this@Workerdashborad, ""+t.message, Toast.LENGTH_SHORT).show()
                                                        }
                                                        override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                                            Toast.makeText(this@Workerdashborad, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()
                                                            getSharedPreferences("user", AppCompatActivity.MODE_PRIVATE).edit().apply {
                                                                putInt("id",id)
                                                                putString("name",name1)
                                                                putString("num",num1)
                                                                putString("email",email)
                                                                putString("address",address1)
                                                                putString("city",city1)
                                                                putString("pass",password1)
                                                                putString("type",type)
                                                                putString("status",status1)
                                                                apply()
                                                            }
                                                            dismiss()
                                                        }
                                                    })
                                            }


                                        }
                                    }
                                    show()
                                }
                            }

                            show()
                        }


                    }

                    R.id.action_Logout -> {logout()
                        popupMenu.dismiss()}

                }
                true
            })
            popupMenu.show()
        }

    }

    private fun readassigning(email: String) {
        val builder = AlertDialog.Builder(this, R.style.TransparentDialog)
        val inflater = this.layoutInflater
        builder.setView(inflater.inflate(R.layout.progressdialog, null))
        builder.setCancelable(false)
        p = builder.create()
        p.show()

        CoroutineScope(Dispatchers.IO).launch {
            RetrofitClient.instance.workeremailrequest(email,"getrequestworkemail")
                .enqueue(object : Callback<requestresponse> {
                    @SuppressLint("SetTextI18n")
                    override fun onResponse(call: Call<requestresponse>, response: Response<requestresponse>) {

                        b.listcomplaints.let {
                            response.body()?.user?.let {
                                    it1 ->
                                it.adapter=workassAdapter(this@Workerdashborad,it1)
                                it.layoutManager= LinearLayoutManager(this@Workerdashborad)
                                Toast.makeText(this@Workerdashborad, "success", Toast.LENGTH_SHORT).show()
                            }
                        }
                        p.dismiss()

                    }

                    override fun onFailure(call: Call<requestresponse>, t: Throwable) {
                        Toast.makeText(this@Workerdashborad, "${t.message}", Toast.LENGTH_SHORT).show()
                        p.dismiss()
                    }

                })
        }
    }

    inner class workassAdapter(var context: Context, var listdata: ArrayList<requestda>):
        RecyclerView.Adapter<workassAdapter.DataViewHolder>(){

        inner class DataViewHolder(val view: CardworkerassginedBinding) : RecyclerView.ViewHolder(view.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
            return DataViewHolder(
                CardworkerassginedBinding.inflate(
                    LayoutInflater.from(context),parent,
                    false))
        }

        private fun callPhoneNumber(num: String) {
            val intent = Intent(Intent.ACTION_CALL)
            intent.data = Uri.parse("tel:$num")

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                context.startActivity(intent)
            } else {
                ActivityCompat.requestPermissions((context as Activity), arrayOf(Manifest.permission.CALL_PHONE), 1)
            }
        }

        private  val bind by lazy {
            CardverficationworkerBinding.inflate(layoutInflater)
        }

        override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {
            with(holder.view){

                listdata[position].apply {
                    tvdate.text=date
                    tvctype.text=ctype
                    tvdescri.text="User words: $udescri"
                    tvvstatus.text="Status: $vstatus"
                    tvuserinfo.text="Name: $name\nAddress: $address"
                    tvuserdetails.setOnClickListener {
                        tvuserinfo.visibility= View.VISIBLE
                    }

                    if(vstatus=="Not Verified"){
                        btnverification.visibility=View.VISIBLE
                    }else {
                        btnverification.visibility=View.GONE
                    }

                    btnverification.setOnClickListener {
                        BottomSheetDialog(context).apply {
                            (bind.root.parent as? ViewGroup)?.removeView(bind.root)
                            setContentView(bind.root)

                            bind.btnsubmit.setOnClickListener {
                                var descri=bind.etdescritpion.text.toString().trim()
                                if(descri.isEmpty()){
                                    bind.etdescritpion.error="Enter your Description"
                                }else{
                                    CoroutineScope(Dispatchers.IO).launch {
                                        RetrofitClient.instance.updateassignverfication(descri,requestID,"updateassignverification")
                                            .enqueue(object: Callback<DefaultResponse> {
                                                override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                                    Toast.makeText(context, ""+t.message, Toast.LENGTH_SHORT).show()
                                                }
                                                override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                                    Toast.makeText(context, "${response.body()!!.message }", Toast.LENGTH_SHORT).show()
                                                    readassigning(email)
                                                    dismiss()
                                                }
                                            })
                                    }
                                }
                            }
                            show()
                        }

                    }
                }

            }
        }



        override fun getItemCount() = listdata.size
    }
}