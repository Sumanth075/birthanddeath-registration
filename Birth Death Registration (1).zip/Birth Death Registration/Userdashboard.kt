package com.example.birthdeathregistration

import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.birthdeathregistration.User.UserHistory
import com.example.birthdeathregistration.User.Userrequest
import com.example.birthdeathregistration.databinding.ActivityUserdashboardBinding
import com.example.birthdeathregistration.databinding.CardprofileBinding
import com.example.birthdeathregistration.model.RetrofitClient
import com.example.birthdeathregistration.model.logout
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Userdashboard : AppCompatActivity() {
    private  val b by lazy { ActivityUserdashboardBinding.inflate(layoutInflater) }
    private  val bind by lazy {
        CardprofileBinding.inflate(layoutInflater)
    }
   var id=0
   var name=""
   var num=""
   var email=""
   var address=""
   var city=""
   var pass=""
   var type=""
   var status=""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(b.root)

        getSharedPreferences("user", MODE_PRIVATE).apply {
            num=getString("num","").toString()
            pass=getString("pass","").toString()
            email=getString("email","").toString()
            name=getString("name","").toString()
            address=getString("address","").toString()
            city=getString("city","").toString()
            type=getString("type","").toString()
            status=getString("status","").toString()
            id=getInt("id",0)
        }

        b.btnlogout.setOnClickListener {logout() }
        b.btnaddrequest.setOnClickListener {
            startActivity(Intent(this,Userrequest::class.java))
        }
        b.btnadminhistory.setOnClickListener {
            startActivity(Intent(this,UserHistory::class.java))
        }

        bind.etname.setText(name)
        bind.etnum.setText(num)
        bind.etaddress.setText(address)
        bind.etcity.setText(city)
        bind.etpassword.setText(pass)


        b.btnprofile.setOnClickListener {
            BottomSheetDialog(this).apply {
                (bind.root.parent as? ViewGroup)?.removeView(bind.root)
                setContentView(bind.root)
                bind.btnsubmit.setOnClickListener {
                    val name1=bind.etname.text.toString().trim()
                    val num1=bind.etnum.text.toString().trim()

                    val address1=bind.etaddress.text.toString().trim()
                    val city1=bind.etcity.text.toString().trim()
                    val password1=bind.etpassword.text.toString().trim()


                    if(name1.isEmpty()){
                        bind.etname.error="Enter Your Name"
                    }else if(num1.isEmpty()){
                        bind.etnum.error="Enter Your Number"
                    }else if(address1.isEmpty()){
                        bind.etaddress.error="Enter Your Address"
                    }else if(city1.isEmpty()){
                        bind.etcity.error="Enter Your city"
                    }else if(password1.isEmpty()){
                        bind.etpassword.error="Enter Your Password"
                    }else if(num1.count()!=10){
                        bind.etnum.error="Enter Your Number properly"
                    }else{
                        CoroutineScope(Dispatchers.IO).launch {
                            RetrofitClient.instance.updateprofile(id,name1,num1,address1,city1,password1,"","updateuser")
                                .enqueue(object: Callback<DefaultResponse> {
                                    override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                        Toast.makeText(this@Userdashboard, ""+t.message, Toast.LENGTH_SHORT).show()
                                    }
                                    override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                        Toast.makeText(this@Userdashboard, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()

                                        getSharedPreferences("user", AppCompatActivity.MODE_PRIVATE).edit().apply {
                                            putInt("id",id)
                                            putString("name",name1)
                                            putString("num",num1)
                                            putString("email",email)
                                            putString("address",address1)
                                            putString("city",city1)
                                            putString("pass",password1)
                                            putString("type",type)
                                            putString("status",status)
                                            apply()
                                        }
                                        dismiss()
                                    }
                                })
                        }


                    }
                }
                show()
            }


        }
    }
}