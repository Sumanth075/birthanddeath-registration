package com.example.birthdeathregistration.User

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.example.birthdeathregistration.R
import com.example.birthdeathregistration.databinding.ActivityViewCerificateBinding
import okhttp3.OkHttpClient
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream

class ViewCerificate : AppCompatActivity() {
    private val b by lazy {
        ActivityViewCerificateBinding.inflate(layoutInflater)
    }
    private lateinit var p: AlertDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(b.root)

        val builder = AlertDialog.Builder(this, R.style.TransparentDialog)
        val inflater = this.layoutInflater
        builder.setView(inflater.inflate(R.layout.progressdialog, null))
        builder.setCancelable(false)
        p = builder.create()
        p.show()

        val photo = Uri.parse(intent.getStringExtra("path"))


        Glide.with(this).load(photo).into(b.btnviewimage)
        p.dismiss()
        b.btndownload.setOnClickListener {

            b.btnviewimage.isDrawingCacheEnabled = true
            val bmp = b.btnviewimage.drawingCache

            // Get storage directory
            val storageLoc = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val file = File(storageLoc, "${System.currentTimeMillis()}.jpg")

            try {
                val fos = FileOutputStream(file)
                bmp.compress(Bitmap.CompressFormat.JPEG, 100, fos)
                fos.close()

                // Scan the file to make it visible in the gallery
                scanFile(this, Uri.fromFile(file))
                Toast.makeText(this, "Report Downloaded Successfully", Toast.LENGTH_LONG).show()

            } catch (e: FileNotFoundException) {
                e.printStackTrace()
            } catch (e: IOException) {
                e.printStackTrace()
            }

        }

    }



    private fun scanFile(context: Context, fromFile: Uri) {
        val scanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
        scanIntent.data = fromFile
        context.sendBroadcast(scanIntent)
    }

}