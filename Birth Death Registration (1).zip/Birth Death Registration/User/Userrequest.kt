package com.example.birthdeathregistration.User

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.birthdeathregistration.MainActivity
import com.example.birthdeathregistration.R
import com.example.birthdeathregistration.databinding.ActivityUserrequestBinding
import com.example.birthdeathregistration.model.RetrofitClient
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.util.Date

class Userrequest : AppCompatActivity() {
    private val b by lazy {
        ActivityUserrequestBinding.inflate(layoutInflater)
    }
    var email = ""

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(b.root)

        val k = arrayOf("choose your choice", "Birth certificate", "Death certificate")

        ArrayAdapter(
            this@Userrequest,
            android.R.layout.simple_list_item_checked, k
        ).apply {
            b.spinnertype.adapter = this
        }


        getSharedPreferences("user", MODE_PRIVATE).apply {

            email = getString("email", "").toString()
        }

        val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
        val currentDate = sdf.format(Date()).toString()

        b.btnsubmit.setOnClickListener {
            var udescr = b.etname.text.toString().trim()
            var ctype = b.spinnertype.selectedItem.toString()


            if (udescr.isEmpty()) {
                b.etname.error = "Enter your Description"
            } else if (ctype == "choose your choice") {
                Toast.makeText(this, "choose your choice properly", Toast.LENGTH_SHORT).show()
            } else {

                CoroutineScope(Dispatchers.IO).launch {
                    RetrofitClient.instance.    addrequest(
                        email,
                        "", "", "",Base64.encodeToString(udescr.toByteArray(),Base64.DEFAULT), ctype, "Not Assigned",
                        "Not Verified", "", "", "", currentDate, "register"
                    )
                        .enqueue(object : Callback<DefaultResponse> {
                            override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                Toast.makeText(this@Userrequest, "" + t.message, Toast.LENGTH_SHORT)
                                    .show()
                            }

                            override fun onResponse(
                                call: Call<DefaultResponse>,
                                response: Response<DefaultResponse>
                            ) {
                                Toast.makeText(
                                    this@Userrequest,
                                    "${response.body()!!.message}",
                                    Toast.LENGTH_SHORT
                                ).show()

                                finish()
                                startActivity(Intent(this@Userrequest,UserHistory::class.java))

                            }
                        })
                }
            }
        }


    }


    override fun onBackPressed() {
        super.onBackPressed()

        finish()
        startActivity(Intent(this@Userrequest,UserHistory::class.java))
    }
}