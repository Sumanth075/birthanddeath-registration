package com.example.birthdeathregistration.Admin

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.birthdeathregistration.R
import com.example.birthdeathregistration.databinding.ActivityAdminworkersBinding
import com.example.birthdeathregistration.databinding.CarduseradminBinding
import com.example.birthdeathregistration.databinding.CardworkersadminsBinding
import com.example.birthdeathregistration.model.RetrofitClient
import com.example.skinsmart.model.Userresponse
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.ymts0579.model.model.DefaultResponse
import com.ymts0579.model.model.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Adminworkers : AppCompatActivity() {
    private val b by lazy {
        ActivityAdminworkersBinding.inflate(layoutInflater)
    }
    private  val bind by lazy {
        CardworkersadminsBinding.inflate(layoutInflater)
    }
    private lateinit var p: AlertDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(b.root)
        
        
        readworker("Worker")

        b.btnaddsupport.setOnClickListener {
            BottomSheetDialog(this).apply {
                (bind.root.parent as? ViewGroup)?.removeView(bind.root)
                setContentView(bind.root)

                bind.btnsignup.setOnClickListener {
                    val name=bind.etname.text.toString().trim()
                    val num=bind.etnum.text.toString().trim()
                    val email=bind.etemail.text.toString().trim()
                    val address=bind.etaddress.text.toString().trim()
                    val city=bind.etcity.text.toString().trim()
                    val password=bind.etpassword.text.toString().trim()


                    if(name.isEmpty()){
                        bind.etname.error="Enter Your Name"
                    }else if(num.isEmpty()){
                        bind.etnum.error="Enter Your Number"
                    }else if(email.isEmpty()){
                        bind.etemail.error="Enter Your Email"
                    }else if(address.isEmpty()){
                        bind.etaddress.error="Enter Your Address"
                    }else if(city.isEmpty()){
                        bind.etcity.error="Enter Your city"
                    }else if(password.isEmpty()){
                        bind.etpassword.error="Enter Your Password"
                    }else if(num.count()!=10){
                        bind.etnum.error="Enter Your Number properly"
                    }else{
                        CoroutineScope(Dispatchers.IO).launch {
                            RetrofitClient.instance.register(name,num,email,address,city,password,"Worker","available","register")
                                .enqueue(object: Callback<DefaultResponse> {
                                    override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                        Toast.makeText(this@Adminworkers, ""+t.message, Toast.LENGTH_SHORT).show()
                                    }
                                    override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                        Toast.makeText(this@Adminworkers, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()
                                        bind.etname.text.clear()
                                        bind.etnum.text.clear()
                                        bind.etemail.text.clear()
                                        bind.etaddress.text.clear()
                                        bind.etcity.text.clear()
                                        bind.etpassword.text.clear()
                                       dismiss()
                                    }
                                })
                        }


                    }
                }
                show()
            }
        }



    }

    private fun readworker(type: String) {
        val builder = AlertDialog.Builder(this, R.style.TransparentDialog)
        val inflater = this.layoutInflater
        builder.setView(inflater.inflate(R.layout.progressdialog, null))
        builder.setCancelable(false)
        p = builder.create()
        p.show()

        CoroutineScope(Dispatchers.IO).launch {
            RetrofitClient.instance.adminworker()
                .enqueue(object : Callback<Userresponse> {
                    @SuppressLint("SetTextI18n")
                    override fun onResponse(call: Call<Userresponse>, response: Response<Userresponse>) {

                        b.listuser.let {
                            response.body()?.user?.let {
                                    it1 ->
                                it.adapter=   workerAdminAdapter(this@Adminworkers, it1)
                                it.layoutManager= LinearLayoutManager(this@Adminworkers)
                                Toast.makeText(this@Adminworkers, "success", Toast.LENGTH_SHORT).show()
                            }
                        }
                        p.dismiss()

                    }

                    override fun onFailure(call: Call<Userresponse>, t: Throwable) {
                        Toast.makeText(this@Adminworkers, "${t.message}", Toast.LENGTH_SHORT).show()
                        p.dismiss()
                    }

                })
        }
    }

    class workerAdminAdapter(var context: Context, var listdata: ArrayList<User>):
        RecyclerView.Adapter<workerAdminAdapter.DataViewHolder>(){

        inner class DataViewHolder(val view: CarduseradminBinding) : RecyclerView.ViewHolder(view.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
            return DataViewHolder(
                CarduseradminBinding.inflate(
                    LayoutInflater.from(context),parent,
                    false))
        }

        private fun callPhoneNumber(num: String) {
            val intent = Intent(Intent.ACTION_CALL)
            intent.data = Uri.parse("tel:$num")

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                context.startActivity(intent)
            } else {
                ActivityCompat.requestPermissions((context as Activity), arrayOf(Manifest.permission.CALL_PHONE), 1)
            }
        }

        override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {
            with(holder.view){

                listdata[position].apply {
                    tvfname.text=name
                    tvfemail.text=email
                    tvfnum.text=num
                    tvfcity.text=city

                    btncall.setOnClickListener {
                        callPhoneNumber(num)
                    }


                    btndelete.setOnClickListener {
                        val alertdialog= AlertDialog.Builder(context)
                        alertdialog.setTitle("Delete")
                        alertdialog.setIcon(R.drawable.logo)
                        alertdialog.setCancelable(false)
                        alertdialog.setMessage("Do you Deleted the Profile?")
                        alertdialog.setPositiveButton("Yes"){ alertdialog, which->

                            deleteCenter(id)
                            alertdialog.dismiss()
                        }

                        alertdialog.show()

                    }
                }

            }
        }

        private fun deleteCenter(id: Int) {
            CoroutineScope(Dispatchers.IO).launch {
                RetrofitClient.instance.Deleteperson(id,"deletetable")
                    .enqueue(object: Callback<DefaultResponse> {
                        override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                            Toast.makeText(context, ""+t.message, Toast.LENGTH_SHORT).show()
                        }
                        override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                            Toast.makeText(context, "${response.body()!!.message }", Toast.LENGTH_SHORT).show()


                        }
                    })
            }

        }


        override fun getItemCount() = listdata.size
    }
}