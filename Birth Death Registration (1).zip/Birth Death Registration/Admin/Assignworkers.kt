package com.example.birthdeathregistration.Admin

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.birthdeathregistration.Admin.AdminRequests.requestAdapter
import com.example.birthdeathregistration.MainActivity
import com.example.birthdeathregistration.R
import com.example.birthdeathregistration.databinding.ActivityAssignworkersBinding
import com.example.birthdeathregistration.databinding.CardassignadminBinding
import com.example.birthdeathregistration.databinding.CarduseradminBinding
import com.example.birthdeathregistration.model.RetrofitClient
import com.example.birthdeathregistration.model.logout
import com.example.skinsmart.model.Userresponse
import com.example.skinsmart.model.requestresponse
import com.ymts0579.model.model.DefaultResponse
import com.ymts0579.model.model.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Assignworkers : AppCompatActivity() {
    private val b by lazy {
        ActivityAssignworkersBinding.inflate(layoutInflater)
    }
    private lateinit var p: AlertDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(b.root)

        var city=intent.getStringExtra("city")
        var rid=intent.getIntExtra("id",0).toString()


          readcity(city.toString(),rid.toString())

    }

    private fun readcity(city: String,rid:String) {
        val builder = AlertDialog.Builder(this, R.style.TransparentDialog)
        val inflater = this.layoutInflater
        builder.setView(inflater.inflate(R.layout.progressdialog, null))
        builder.setCancelable(false)
        p = builder.create()
        p.show()

        CoroutineScope(Dispatchers.IO).launch {
            RetrofitClient.instance.Viewcity(city,"Viewcity")
                .enqueue(object : Callback<Userresponse> {
                    @SuppressLint("SetTextI18n")
                    override fun onResponse(call: Call<Userresponse>, response: Response<Userresponse>) {

                        b.main.let {
                            response.body()?.user?.let {
                                    it1 ->
                              it.adapter=workerAdminsAdapter(this@Assignworkers,it1,city,
                                      rid)
                                it.layoutManager= LinearLayoutManager(this@Assignworkers)
                                Toast.makeText(this@Assignworkers, "success", Toast.LENGTH_SHORT).show()
                            }
                        }
                        p.dismiss()

                    }

                    override fun onFailure(call: Call<Userresponse>, t: Throwable) {
                        Toast.makeText(this@Assignworkers, "${t.message}", Toast.LENGTH_SHORT).show()
                        p.dismiss()
                    }

                })
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()

        finish()
        startActivity(Intent(this,AdminRequests::class.java))
    }

    inner class workerAdminsAdapter(var context: Context, var listdata: ArrayList<User>,var city:String,var
    rid:String):
        RecyclerView.Adapter<workerAdminsAdapter.DataViewHolder>(){

        inner class DataViewHolder(val view: CardassignadminBinding) : RecyclerView.ViewHolder(view.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
            return DataViewHolder(
                CardassignadminBinding.inflate(
                    LayoutInflater.from(context),parent,
                    false))
        }

        private fun callPhoneNumber(num: String) {
            val intent = Intent(Intent.ACTION_CALL)
            intent.data = Uri.parse("tel:$num")

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                context.startActivity(intent)
            } else {
                ActivityCompat.requestPermissions((context as Activity), arrayOf(Manifest.permission.CALL_PHONE), 1)
            }
        }

        override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {
            with(holder.view){

                listdata[position].apply {
                    tvfname.text=name
                    tvfemail.text=email
                    tvfnum.text=num


                    holder.itemView.setOnClickListener {
                        val alertdialog= AlertDialog.Builder(context)
                        alertdialog.setTitle("Assgin to $name")
                        alertdialog.setIcon(R.drawable.logo)
                        alertdialog.setCancelable(false)
                        alertdialog.setPositiveButton("Yes"){ alertdialog, which->
                            CoroutineScope(Dispatchers.IO).launch {
                                RetrofitClient.instance.updateassign(name,num,email,"Assigned",rid.toInt(),"updateassign")
                                    .enqueue(object: Callback<DefaultResponse> {
                                        override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                            Toast.makeText(context, ""+t.message, Toast.LENGTH_SHORT).show()
                                        }
                                        override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                            Toast.makeText(context, "${response.body()!!.message }", Toast.LENGTH_SHORT).show()
                                            (context as Activity).apply {
                                                finish()
                                                startActivity(Intent(this@apply,AdminRequests::class.java))
                                                readcity(city.toString(),rid.toString())
                                            }


                                        }
                                    })
                            }
                        }
                        alertdialog.setNegativeButton("No"){alertdialog,which->
                            Toast.makeText(context,"thank you", Toast.LENGTH_SHORT).show()
                            alertdialog.dismiss()
                        }
                        alertdialog.show()
                    }

                }

            }
        }






        override fun getItemCount() = listdata.size
    }
}