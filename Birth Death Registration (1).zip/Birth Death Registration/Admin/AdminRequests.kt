package com.example.birthdeathregistration.Admin

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.birthdeathregistration.R
import com.example.birthdeathregistration.User.UserHistory.historyAdapter
import com.example.birthdeathregistration.databinding.ActivityAdminRequestsBinding
import com.example.birthdeathregistration.databinding.CardadrequestBinding
import com.example.birthdeathregistration.databinding.CardhistoryBinding
import com.example.birthdeathregistration.model.RetrofitClient
import com.example.skinsmart.model.requestda
import com.example.skinsmart.model.requestresponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AdminRequests : AppCompatActivity() {
    private  val b by lazy {
        ActivityAdminRequestsBinding.inflate(layoutInflater)
    }
    private lateinit var p: AlertDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(b.root)


        readrequest()

    }

    private fun readrequest() {
        val builder = AlertDialog.Builder(this, R.style.TransparentDialog)
        val inflater = this.layoutInflater
        builder.setView(inflater.inflate(R.layout.progressdialog, null))
        builder.setCancelable(false)
        p = builder.create()
        p.show()

        CoroutineScope(Dispatchers.IO).launch {
            RetrofitClient.instance.getrequest("getrequest")
                .enqueue(object : Callback<requestresponse> {
                    @SuppressLint("SetTextI18n")
                    override fun onResponse(call: Call<requestresponse>, response: Response<requestresponse>) {

                        b.listrequest.let {
                            response.body()?.user?.let {
                                    it1 ->
                                it.adapter= requestAdapter(this@AdminRequests,it1)
                                it.layoutManager= LinearLayoutManager(this@AdminRequests)
                                Toast.makeText(this@AdminRequests, "success", Toast.LENGTH_SHORT).show()
                            }
                        }
                        p.dismiss()

                    }

                    override fun onFailure(call: Call<requestresponse>, t: Throwable) {
                        Toast.makeText(this@AdminRequests, "${t.message}", Toast.LENGTH_SHORT).show()
                        p.dismiss()
                    }

                })
        }
    }

    class requestAdapter(var context: Context, var listdata: ArrayList<requestda>):
        RecyclerView.Adapter<requestAdapter.DataViewHolder>(){

        inner class DataViewHolder(val view: CardadrequestBinding) : RecyclerView.ViewHolder(view.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
            return DataViewHolder(
                CardadrequestBinding.inflate(
                    LayoutInflater.from(context),parent,
                    false))
        }

        private fun callPhoneNumber(num: String) {
            val intent = Intent(Intent.ACTION_CALL)
            intent.data = Uri.parse("tel:$num")

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                context.startActivity(intent)
            } else {
                ActivityCompat.requestPermissions((context as Activity), arrayOf(Manifest.permission.CALL_PHONE), 1)
            }
        }

        override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {
            with(holder.view){

                listdata[position].apply {
                    tvdate.text=date
                    tvctype.text=ctype
                    tvdescri.text="User words: $udescri"
                    tvvstatus.text="Status: $astatus"
                    tvastatus.text="Status: $vstatus"
                    tvuserinfo.text="Name: $name\nAddress: $address"

                    tvworkerinfo.text="Name: $wuname\nNumber: $wunum"

                    tvuserdetails.setOnClickListener {
                        tvuserinfo.visibility= View.VISIBLE
                    }

                    tvworkerdetails.setOnClickListener {
                        tvworkerinfo.visibility=View.VISIBLE
                    }


                    if(astatus=="Assigned"){
                        tvastatus.visibility=View.VISIBLE
                        tvworkerdetails.visibility=View.VISIBLE
                        tvworkerinfo.visibility=View.VISIBLE
                    }else{
                        tvastatus.visibility=View.GONE
                        tvworkerdetails.visibility=View.GONE
                        tvworkerinfo.visibility=View.GONE
                    }




                    if(vstatus=="Verified"){
                        if(path==""){
                            btnupload.visibility=View.VISIBLE
                        }else{
                            btnupload.visibility=View.GONE
                        }
                    }


                    btnupload.setOnClickListener {
                        context.startActivity(Intent(context,Uploadcerificate::class.java).apply {
                            putExtra("rid",requestID)
                        })

                    }

                    holder.itemView.setOnClickListener {
                        if(astatus=="Not Assigned"){
                            context.startActivity(Intent(context,Assignworkers::class.java).apply {
                                putExtra("city",city)
                                putExtra("id",requestID)
                            })
                        }else{
                            Toast.makeText(context, "you already Assigned", Toast.LENGTH_SHORT).show()
                        }
                    }


                }

            }
        }



        override fun getItemCount() = listdata.size
    }
}