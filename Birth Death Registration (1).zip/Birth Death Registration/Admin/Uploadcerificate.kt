package com.example.birthdeathregistration.Admin

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.birthdeathregistration.R
import com.example.birthdeathregistration.databinding.ActivityUploadcerificateBinding
import com.example.birthdeathregistration.model.RetrofitClient
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Uploadcerificate : AppCompatActivity() {
    private val b by lazy {
        ActivityUploadcerificateBinding.inflate(layoutInflater)
    }
    var uri: Uri? = null
    var encoded=""




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(b.root)


        val activity = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            it.data?.data?.let {
                b.imageadd.setImageURI(it)
                uri = it
            }
        }

        b.imageadd.setOnClickListener {
            Intent(Intent.ACTION_GET_CONTENT).apply {
                type="image/*"
                activity.launch(this)
            }
        }


        var rid=intent.getIntExtra("rid",0)
        b.btnsubmit.setOnClickListener {
            var descri=b.etdescritpion.text.toString().trim()
            if(descri.isEmpty()){
                b.etdescritpion.error="Enter your Description"
            }else{
                contentResolver.openInputStream(uri!!)?.readBytes()?.let {
                    encoded= Base64.encodeToString(it, Base64.NO_WRAP)}
                CoroutineScope(Dispatchers.IO).launch {
                    RetrofitClient.instance.updateadminrequest(encoded,descri,rid,"updateadminrequest")
                        .enqueue(object: Callback<DefaultResponse> {
                            override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                Toast.makeText(this@Uploadcerificate, ""+t.message, Toast.LENGTH_SHORT).show()
                            }
                            override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                Toast.makeText(this@Uploadcerificate, "${response.body()!!.message }", Toast.LENGTH_SHORT).show()

                            }
                        })
                }
            }

        }

    }
}