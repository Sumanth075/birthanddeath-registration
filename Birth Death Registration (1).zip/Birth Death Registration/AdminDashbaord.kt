package com.example.birthdeathregistration

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.birthdeathregistration.Admin.AdminRequests
import com.example.birthdeathregistration.Admin.Adminworkers
import com.example.birthdeathregistration.Admin.Adminworkers.workerAdminAdapter
import com.example.birthdeathregistration.databinding.ActivityAdminDashbaordBinding
import com.example.birthdeathregistration.databinding.CardlistusersBinding
import com.example.birthdeathregistration.databinding.CarduseradminBinding
import com.example.birthdeathregistration.model.RetrofitClient
import com.example.birthdeathregistration.model.logout
import com.example.skinsmart.model.Userresponse
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.ymts0579.model.model.DefaultResponse
import com.ymts0579.model.model.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AdminDashbaord : AppCompatActivity() {
    private  val b by lazy {
        ActivityAdminDashbaordBinding.inflate(layoutInflater)
    }
    private lateinit var p: AlertDialog
    private val bind by lazy {
        CardlistusersBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(b.root)


        b.imageView2.setOnClickListener { logout() }
        b.btnadminworker.setOnClickListener { startActivity(Intent(this,Adminworkers::class.java)) }
        b.btnadminrequest.setOnClickListener {
            startActivity(Intent(this,AdminRequests::class.java))
        }

        b.btnadminuser.setOnClickListener {

            val builder = AlertDialog.Builder(this, R.style.TransparentDialog)
            val inflater = this.layoutInflater
            builder.setView(inflater.inflate(R.layout.progressdialog, null))
            p = builder.create()
            p.show()
            BottomSheetDialog(this).apply {
                (bind.root.parent as? ViewGroup)?.removeView(bind.root)
                setContentView(bind.root)

                CoroutineScope(Dispatchers.IO).launch {
                    RetrofitClient.instance.adminuser()
                        .enqueue(object : Callback<Userresponse> {
                            @SuppressLint("SetTextI18n")
                            override fun onResponse(call: Call<Userresponse>, response: Response<Userresponse>) {

                                bind.listuser.let {
                                    response.body()?.user?.let {
                                            it1 ->
                                        it.adapter=   userAdminAdapter(this@AdminDashbaord, it1)
                                        it.layoutManager= LinearLayoutManager(this@AdminDashbaord)
                                        Toast.makeText(this@AdminDashbaord, "success", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                p.dismiss()
                                show()
                            }

                            override fun onFailure(call: Call<Userresponse>, t: Throwable) {
                                Toast.makeText(this@AdminDashbaord, "${t.message}", Toast.LENGTH_SHORT).show()
                                p.dismiss()
                            }

                        })
                }
            }
        }
    }

    class userAdminAdapter(var context: Context, var listdata: ArrayList<User>):
        RecyclerView.Adapter<userAdminAdapter.DataViewHolder>(){

        inner class DataViewHolder(val view: CarduseradminBinding) : RecyclerView.ViewHolder(view.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
            return DataViewHolder(
                CarduseradminBinding.inflate(
                    LayoutInflater.from(context),parent,
                    false))
        }

        private fun callPhoneNumber(num: String) {
            val intent = Intent(Intent.ACTION_CALL)
            intent.data = Uri.parse("tel:$num")

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                context.startActivity(intent)
            } else {
                ActivityCompat.requestPermissions((context as Activity), arrayOf(Manifest.permission.CALL_PHONE), 1)
            }
        }

        override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {
            with(holder.view){

                listdata[position].apply {
                    tvfname.text=name
                    tvfemail.text=email
                    tvfnum.text=num
                    tvfcity.text=city

                    btncall.setOnClickListener {
                        callPhoneNumber(num)
                    }


                    btndelete.visibility= View.GONE
                }

            }
        }




        override fun getItemCount() = listdata.size
    }
}