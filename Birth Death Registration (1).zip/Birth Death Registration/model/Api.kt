package com.example.birthdeathregistration.model
import com.example.skinsmart.model.Userresponse
import com.example.skinsmart.model.requestresponse
import com.ymts0579.model.model.DefaultResponse
import com.ymts0579.model.model.LoginResponse
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST

interface Api {
    @FormUrlEncoded
    @POST("User.php")
    fun register(
        @Field("name")name:String,
        @Field("num")num:String,
        @Field("email")email:String,
        @Field("address")address:String,
        @Field("city")city:String,
        @Field("pass")pass:String,
        @Field("type")type:String,
        @Field("status")status:String,
        @Field("condition") condition:String,
    ): Call<DefaultResponse>





    @FormUrlEncoded
    @POST("User.php")
    fun login(@Field("email") email:String, @Field("pass") pass:String,
              @Field("condition") condition:String): Call<LoginResponse>


    @FormUrlEncoded
    @POST("User.php")
    fun updateprofile(
        @Field("id") id:Int,
        @Field("name")name:String,
        @Field("num")num:String,
        @Field("address")address:String,
        @Field("city")city:String,
        @Field("pass")pass:String,

        @Field("status")status:String,
        @Field("condition") condition:String,
    ): Call<DefaultResponse>


    @FormUrlEncoded
    @POST("User.php")
    fun Viewcity(
        @Field("city")city:String,
        @Field("condition") condition:String,
    ): Call<Userresponse>



    @GET("getuser.php")
    fun adminuser():Call<Userresponse>


    @GET("getworker.php")
    fun adminworker():Call<Userresponse>



    @FormUrlEncoded
    @POST("users.php")
    fun Deleteperson(
        @Field("id")id:Int,
        @Field("condition") condition:String,
    ): Call<DefaultResponse>

    @FormUrlEncoded
    @POST("UserRequest.php")
    fun addrequest(
        @Field("uemail")uemail:String,
        @Field("wuname")wuname:String,
        @Field("wunum")wunum:String,
        @Field("wemail")wemail:String,
        @Field("udescri")udescri:String,
        @Field("ctype")ctype:String,
        @Field("astatus")astatus:String,
        @Field("vstatus")vstatus:String,
        @Field("vdescri")vdescri:String,
        @Field("adescri")adescri:String,
        @Field("path") path:String,
        @Field("date") date:String,
        @Field("condition") condition:String,
    ):Call<DefaultResponse>


    @FormUrlEncoded
    @POST("UserRequest.php")
    fun useremailrequest(
        @Field("uemail")uemail:String,
        @Field("condition") condition:String,
    ):Call<requestresponse>


    @FormUrlEncoded
    @POST("UserRequest.php")
    fun workeremailrequest(
        @Field("wemail")wemail:String,
        @Field("condition") condition:String,
    ):Call<requestresponse>



    @FormUrlEncoded
    @POST("UserRequest.php")
    fun getrequest(
        @Field("condition") condition:String,
    ):Call<requestresponse>

    @FormUrlEncoded
    @POST("UserRequest.php")
    fun updateassign(
        @Field("wuname")wuname:String,
        @Field("wunum")wunum:String,
        @Field("wemail")wemail:String,
        @Field("astatus")astatus:String,
        @Field("id")id:Int,
        @Field("condition") condition:String,
    ):Call<DefaultResponse>


    @FormUrlEncoded
    @POST("UserRequest.php")
    fun updateassignverfication(
        @Field("vdescri")vdescri:String,
        @Field("id")id:Int,
        @Field("condition") condition:String,
    ):Call<DefaultResponse>


    @FormUrlEncoded
    @POST("UserRequest.php")
    fun updateadminrequest(
        @Field("path") path:String,
        @Field("adescri")adescri:String,
        @Field("id")id:Int,
        @Field("condition") condition:String,
    ):Call<DefaultResponse>




}