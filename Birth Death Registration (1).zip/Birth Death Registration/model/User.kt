package com.ymts0579.model.model

data class User(
    var id:Int,
    var name:String,
    var num:String,
    var email:String,
    var address:String,
    var city:String,
    var pass:String,
    var type:String,
    var status:String,
    var descrip:String,
    var timing:String
    )


