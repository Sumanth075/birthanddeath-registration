package com.example.skinsmart.model

import android.net.http.SslCertificate.DName
import com.google.gson.annotations.SerializedName
import com.ymts0579.model.model.User

class requestresponse (val error: Boolean, val message:String, var user:ArrayList<requestda>){
}


data class requestda(
    var requestID:Int,
    var uemail:String,
    var wuname:String,
    var wunum:String,
    var wemail:String,
    var udescri:String,
    var ctype:String,
    var astatus:String,
    var vstatus:String,
    var vdescri:String,
    var adescri:String,
    var path:String,
    var date:String,
    var name:String,
    var num:String,
    var address:String,
    var city:String,

    )