package com.ymts0579.model.model

data class LoginResponse(val error: Boolean, val message:String,var user:User)